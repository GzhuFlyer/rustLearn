// use crate::front_of_house;
pub mod front_of_house;
pub use crate::front_of_house::hosting;
// pub mod lib;
// pub use crate::lib::eat_at_restaurant;

use std::collections::HashMap;
fn main() {
    let mut map = HashMap::new();
    map.insert(1, 2);
    // lib::eat_at_restaurant();
    hosting::add_to_waitlist();
    println!("hello world");
}
